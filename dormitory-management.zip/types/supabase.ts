export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      dormitories: {
        Row: {
          id: string
          name: string
          location: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          location?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          location?: string | null
          created_at?: string
        }
      }
      rooms: {
        Row: {
          id: string
          dorm_id: string
          name: string
          floor: number | null
          type: string | null
          price: number | null
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          dorm_id: string
          name: string
          floor?: number | null
          type?: string | null
          price?: number | null
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          dorm_id?: string
          name?: string
          floor?: number | null
          type?: string | null
          price?: number | null
          status?: string
          created_at?: string
        }
      }
      tenants: {
        Row: {
          id: string
          name: string | null
          phone: string | null
          note: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name?: string | null
          phone?: string | null
          note?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          name?: string | null
          phone?: string | null
          note?: string | null
          created_at?: string
        }
      }
      contracts: {
        Row: {
          id: string
          tenant_id: string
          room_id: string
          start_date: string | null
          end_date: string | null
          status: string
          deposit: number | null
          created_at: string
        }
        Insert: {
          id?: string
          tenant_id: string
          room_id: string
          start_date?: string | null
          end_date?: string | null
          status?: string
          deposit?: number | null
          created_at?: string
        }
        Update: {
          id?: string
          tenant_id?: string
          room_id?: string
          start_date?: string | null
          end_date?: string | null
          status?: string
          deposit?: number | null
          created_at?: string
        }
      }
      utilities: {
        Row: {
          id: string
          room_id: string
          month: string | null
          water_unit: number | null
          electricity_unit: number | null
          water_rate: number | null
          electricity_rate: number | null
          created_at: string
        }
        Insert: {
          id?: string
          room_id: string
          month?: string | null
          water_unit?: number | null
          electricity_unit?: number | null
          water_rate?: number | null
          electricity_rate?: number | null
          created_at?: string
        }
        Update: {
          id?: string
          room_id?: string
          month?: string | null
          water_unit?: number | null
          electricity_unit?: number | null
          water_rate?: number | null
          electricity_rate?: number | null
          created_at?: string
        }
      }
      payments: {
        Row: {
          id: string
          contract_id: string
          month: string | null
          amount: number | null
          status: string
          paid_at: string | null
          note: string | null
          created_at: string
        }
        Insert: {
          id?: string
          contract_id: string
          month?: string | null
          amount?: number | null
          status?: string
          paid_at?: string | null
          note?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          contract_id?: string
          month?: string | null
          amount?: number | null
          status?: string
          paid_at?: string | null
          note?: string | null
          created_at?: string
        }
      }
    }
  }
}
