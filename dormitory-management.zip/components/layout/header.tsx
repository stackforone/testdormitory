"use client"

import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import { ModeToggle } from "@/components/mode-toggle"
import { cn } from "@/lib/utils"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Building2 } from "lucide-react"

export default function Header() {
  const pathname = usePathname()
  const [title, setTitle] = useState("")

  useEffect(() => {
    // กำหนดชื่อหน้าตามเส้นทาง
    const pathMap: Record<string, string> = {
      "/dashboard": "แดชบอร์ด",
      "/dormitories": "จัดการหอพัก",
      "/rooms": "จัดการห้องพัก",
      "/tenants": "จัดการผู้เช่า",
      "/contracts": "สัญญาเช่า",
      "/utilities": "ค่าน้ำ-ค่าไฟ",
      "/payments": "การชำระเงิน",
      "/reports": "รายงาน",
      "/overview": "ภาพรวมหอพัก",
    }

    setTitle(pathMap[pathname] || "ระบบจัดการหอพัก")
  }, [pathname])

  return (
    <header className={cn("sticky top-0 z-10 flex h-14 items-center gap-4 border-b bg-background px-4 lg:px-6")}>
      <h1 className="text-lg font-semibold">{title}</h1>
      <div className="ml-auto flex items-center gap-2">
        <ModeToggle />
        <Avatar className="h-8 w-8">
          <AvatarFallback className="bg-primary text-primary-foreground">
            <Building2 className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
      </div>
    </header>
  )
}
