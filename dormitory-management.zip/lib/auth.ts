"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"

// รหัสผ่านคงที่สำหรับเข้าสู่ระบบ
const ADMIN_PASSWORD = "987789"

// ตรวจสอบการเข้าสู่ระบบ
export async function login(password: string) {
  if (password === ADMIN_PASSWORD) {
    // สร้าง cookie สำหรับเก็บสถานะการเข้าสู่ระบบ
    cookies().set("auth", "authenticated", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 1 สัปดาห์
      path: "/",
    })

    return { success: true }
  }

  return { success: false, error: "รหัสผ่านไม่ถูกต้อง" }
}

// ออกจากระบบ
export async function logout() {
  cookies().delete("auth")
  redirect("/login")
}

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบแล้วหรือไม่
export async function isAuthenticated() {
  const authCookie = cookies().get("auth")
  return authCookie?.value === "authenticated"
}

// Middleware สำหรับตรวจสอบการเข้าสู่ระบบ
export async function checkAuth() {
  const isLoggedIn = await isAuthenticated()

  if (!isLoggedIn) {
    redirect("/login")
  }
}
