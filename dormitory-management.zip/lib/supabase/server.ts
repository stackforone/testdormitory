import { createClient } from "@supabase/supabase-js"
import type { Database } from "@/types/supabase"

// สร้าง Supabase client สำหรับใช้ในฝั่ง server
export const createServerClient = () => {
  const supabaseUrl = process.env.SUPABASE_URL!
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

  return createClient<Database>(supabaseUrl, supabaseKey, {
    auth: {
      persistSession: false,
    },
  })
}
