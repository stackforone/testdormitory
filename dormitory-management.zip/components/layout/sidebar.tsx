"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  Building2,
  LayoutDashboard,
  DoorOpen,
  Users,
  FileText,
  Droplets,
  CreditCard,
  BarChart3,
  Menu,
  LogOut,
  Home,
} from "lucide-react"
import { logout } from "@/lib/auth"

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {}

export default function Sidebar({ className }: SidebarProps) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const routes = [
    {
      label: "แดชบอร์ด",
      icon: LayoutDashboard,
      href: "/dashboard",
      active: pathname === "/dashboard",
    },
    {
      label: "จัดการหอพัก",
      icon: Building2,
      href: "/dormitories",
      active: pathname === "/dormitories",
    },
    {
      label: "จัดการห้องพัก",
      icon: DoorOpen,
      href: "/rooms",
      active: pathname === "/rooms",
    },
    {
      label: "จัดการผู้เช่า",
      icon: Users,
      href: "/tenants",
      active: pathname === "/tenants",
    },
    {
      label: "สัญญาเช่า",
      icon: FileText,
      href: "/contracts",
      active: pathname === "/contracts",
    },
    {
      label: "ค่าน้ำ-ค่าไฟ",
      icon: Droplets,
      href: "/utilities",
      active: pathname === "/utilities",
    },
    {
      label: "การชำระเงิน",
      icon: CreditCard,
      href: "/payments",
      active: pathname === "/payments",
    },
    {
      label: "รายงาน",
      icon: BarChart3,
      href: "/reports",
      active: pathname === "/reports",
    },
    {
      label: "ภาพรวมหอพัก",
      icon: Home,
      href: "/overview",
      active: pathname === "/overview",
    },
  ]

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild className="lg:hidden">
          <Button variant="outline" size="icon" className="ml-2 mt-2">
            <Menu className="h-5 w-5" />
            <span className="sr-only">เปิดเมนู</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <MobileSidebar routes={routes} setOpen={setOpen} />
        </SheetContent>
      </Sheet>
      <div className={cn("hidden border-r bg-card lg:block w-64", className)}>
        <DesktopSidebar routes={routes} />
      </div>
    </>
  )
}

interface SidebarNavProps {
  routes: {
    label: string
    icon: React.ElementType
    href: string
    active: boolean
  }[]
  setOpen?: (open: boolean) => void
}

function MobileSidebar({ routes, setOpen }: SidebarNavProps) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-14 items-center border-b px-4">
        <Link href="/dashboard" className="flex items-center gap-2 font-semibold" onClick={() => setOpen?.(false)}>
          <Building2 className="h-5 w-5 text-primary" />
          <span>ระบบจัดการหอพัก</span>
        </Link>
      </div>
      <ScrollArea className="flex-1 px-2 py-2">
        <nav className="flex flex-col gap-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              onClick={() => setOpen?.(false)}
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                route.active ? "bg-primary text-primary-foreground" : "hover:bg-muted",
              )}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}
        </nav>
      </ScrollArea>
      <div className="border-t p-2">
        <form action={logout}>
          <Button variant="ghost" className="w-full justify-start gap-2 text-sm font-normal" type="submit">
            <LogOut className="h-5 w-5" />
            ออกจากระบบ
          </Button>
        </form>
      </div>
    </div>
  )
}

function DesktopSidebar({ routes }: SidebarNavProps) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-14 items-center border-b px-4">
        <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
          <Building2 className="h-5 w-5 text-primary" />
          <span>ระบบจัดการหอพัก</span>
        </Link>
      </div>
      <ScrollArea className="flex-1 px-2 py-2">
        <nav className="flex flex-col gap-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                route.active ? "bg-primary text-primary-foreground" : "hover:bg-muted",
              )}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}
        </nav>
      </ScrollArea>
      <div className="border-t p-2">
        <form action={logout}>
          <Button variant="ghost" className="w-full justify-start gap-2 text-sm font-normal" type="submit">
            <LogOut className="h-5 w-5" />
            ออกจากระบบ
          </Button>
        </form>
      </div>
    </div>
  )
}
